import React from 'react';
import MapSection from './components/lnesc/MapSection';

export default function App() {
  return (
    <div className="min-h-screen bg-white w-full">
      <MapSection />
    </div>
  );
}
